package CheckOutSystem;

public class Manager {

}
