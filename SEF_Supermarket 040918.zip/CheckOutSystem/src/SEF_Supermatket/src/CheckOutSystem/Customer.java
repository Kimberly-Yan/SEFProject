package CheckOutSystem;

import java.util.ArrayList;

public class Customer {
	protected String id;
	private String firstName;
	private String lastName;
	private double points;
	ArrayList<CreditCard> cards = new ArrayList<CreditCard>();
	
	public Customer(String id, String firstName, String lastName) {
		this.id = id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.points = 0;
	}
	
	public String getName() {
		return this.firstName + ' ' + this.lastName;
	}
	
	public double getCurrentPoints() {
		return this.points;
	}
	
	public void addPoints(double amount) {
		this.points += amount;
	}
	
	public void deducePoints(double amount) {
		if(amount <= this.points) {
			this.points -= amount;			
		}
	}
	
	public void addCreditCard(CreditCard card) {
		this.cards.add(card);
	}
	
	
	
}
