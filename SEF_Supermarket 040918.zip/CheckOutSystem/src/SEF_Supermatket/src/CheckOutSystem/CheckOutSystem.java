package CheckOutSystem;

import java.util.ArrayList;
import java.util.Scanner;

public class CheckOutSystem {
	ArrayList<Product> productList = new ArrayList<Product>();
	ArrayList<Customer> customerList = new ArrayList<Customer>();
//	ArrayList<Employee> employeeList = new ArrayList<Employee>();
//	Manager manager = new Manager();
	ArrayList<Discount> discountList = new ArrayList<Discount>();
	
	public CheckOutSystem() {
		generateProducts();
		generateCustomers();
		generateDiscounts();
	}
	
	public void startProgram() {
		while(true) {
			System.out.println("------------ CHECK OUT SYSTEM -------------\n");
			System.out.println("1. Customer Login");
			System.out.println("2. Staff Login");
			System.out.println("- Enter Your Choice: ");
			
			Scanner input = new Scanner(System.in);
			String choice = input.next();
			
			switch(choice) {
				case "1": {
					// customer login
					boolean repeated = true;
					while (repeated) {
						System.out.println("\n------------ CUSTOMER PORTAL -------------\n");
						System.out.println("1. Checkout\n");
						System.out.println("2. Check Price\n");
						System.out.println("3. Check Sale Discount\n");
						System.out.println("4. Top Up\n");
						System.out.println("5. Exit\n");
						System.out.println("- Enter Your Choice: ");
						
						String customerChoice = input.next();
						
						switch(customerChoice) {
							case "1":
								customerCheckout();
								break;
							case "2":
								customerCheckPrice();
								break;
							case "3":
								customerCheckPromotions();
								break;
							case "4":
								customerTopUp();
								break;
							case "5":
								repeated = false;
								break;
							default: 
								System.out.println("\nInvalid Choice! Please enter a choice between 1 and 5.");
								break;
						} 
					}
					break;
					
				} // end case 1
				
				// staff login
				case "2": {
					break;
				}
				
				default: 
					System.out.println("Invalid Choice! Please enter a choice between 1 and 2.");
				
			} // end outer switch statement.\
			
			
		} // end outer while loop
		
		
	}
	
	public void customerCheckout() {
		boolean repeated = true;
		Sale sale = new Sale("s1");
		
		while(repeated) {
			System.out.println("\nChoose 1 from 2 options below.\n\n");
			System.out.println("1. Enter Product ID\n");
			System.out.println("2. Choose product ID from list\n");
			System.out.println("- Enter your choice: ");
			
			int choice = 0;
			Scanner input = new Scanner(System.in);
			
			try {
				choice = input.nextInt();
			} catch(Exception e) {
				System.out.println("Invalid choice! Please choose between 1 and 2.");
				continue;
			}
			
			// get product id from input
			String productId = "";
			
			switch(choice) {
				case 1: // customer enters product id
					System.out.println("- Enter product ID: ");
					productId = input.next();
					break;
				case 2: // customer look for product id in a product list
					for(int i = 0; i < productList.size(); i++) {
						System.out.println(productList.get(i).getDetails());
					}
					System.out.println("\n- Enter product ID: ");
					productId = input.next();
					break;
				default: // choice is not 1 or 2, customer has to choose again
					System.out.println("Invalid choice! Please choose between 1 and 2.");
					break;
			}
			
			// if choice is not valid, start again from next iteration
			if(choice != 1 && choice != 2) {
				continue;
			}
			
			
			// if choice is valid, check if product exists. If it does, get it from the list by the input id.
			Product product = null;
			for(int i = 0; i < productList.size(); i++) {
				if(productList.get(i).id.equalsIgnoreCase(productId)) {
					product = productList.get(i);
				}
			}
			
			// if product is not found, start again from next iteration
			if(product == null) {
				System.out.println("\nProduct does not exist. Please enter a correct product ID.");
				continue;
			} else { // if product is found, ask for quantity
				int quantity = 0;
				while(true) {
					try { // validate quantity input
						System.out.println("\n- Enter quantity: \n");
						quantity = input.nextInt();
			
						if(quantity == 0) {
							System.out.println("Quantity must be bigger than 0!");
							continue;
						}
						
						break;
					} catch(Exception e) { // in case input is not integer.
						System.out.println("\nInvalid input! Please enter a number!");
						input.next();
					}
				}
				
				// check for possible discount
				double price = product.price;
				for(int i = 0; i < discountList.size(); i++) {
					if(discountList.get(i).productId.equalsIgnoreCase(productId) && quantity >= discountList.get(i).quantityToDiscount) {
						price = discountList.get(i).discountPrice;
					}
				}
				
				// create new sale line item
				SaleLineItem item = new SaleLineItem(product.id, sale.id, quantity, price);
				
				// add item to sale
				sale.addItemToList(item);
				
				// display cart
				System.out.println("\nItem has been added to you card.");
				System.out.println(sale.getDetails());
				
				// ask if user want to add more item or make payment
				boolean repeated3 = true;
				while(repeated3) {
					System.out.println("\n1. Add more item to cart.");
					System.out.println("\n2. Make payment");
					System.out.println("\n3. Remove this item");
					System.out.println("\n4. Cancel");
					System.out.println("\n- Enter your choice: ");
					int choice3 = 0;
					try {
						choice3 = input.nextInt();
					} catch(Exception e) { // if input is not integer
						System.out.println("Input must be between 1 and 4");
						input.next();
					}
					
					if(choice < 1 && choice > 4) { // if input is not 1 to 4.
						System.out.println("Input must be between 1 and 4");
						continue;
					}
					
					if(choice3 == 1) {
						break;
					} else if(choice3 == 2) {
						// make payment
						while(true) {
							System.out.println("\nEnter card number: ");
							String cardNo = input.next();
							System.out.println("\nEnter customer ID: ");
							String customerId = input.next();
							
							CreditCard paymentCard = null;
							// check if card exists
							for(int i = 0; i < customerList.size(); i++) {
								if(customerList.get(i).id.equalsIgnoreCase(customerId)) {
									for(int y = 0; y < customerList.get(i).cards.size(); y++) {
										if(customerList.get(i).cards.get(y).cardNumber.equalsIgnoreCase(cardNo)) {
											paymentCard = customerList.get(i).cards.get(y);
											break;
										}
									}
								}
							}
							
							if(paymentCard == null) { // card does not exist
								System.out.println("\nCard does not exist. Please try again!");
								continue;
							} else { 
								if(paymentCard.makePayment(sale.getTotal())) { // payment succeeds
									System.out.println("\nCard Approved!");
									System.out.println(sale.getDetails());
									break;
								} else {
									System.out.println("\nCard Declined! Please top up your card or try another one.");
									// options to try again or cancel.
									break;
								}
							}
						
						}
						repeated = false;
						break;
					} else if(choice3 == 3) { // remove this item.
						sale.removeItemFromList(item);
						System.out.println("\nItem has been removed!");
						System.out.println(sale.getDetails());
						continue;
					} else if(choice == 4) { // cancel and go back to customer portal
						repeated = false;
						break;
					}
					
				}
				
			}
			
		}
	}
	
	public void customerCheckPrice() {
		while(true) {
			Scanner input = new Scanner(System.in);
			System.out.println("\n- Enter Product ID: ");
			String productId = input.next();
			
			String details = "";
			for(int i = 0; i < productList.size(); i++) {
				if(productList.get(i).id.equalsIgnoreCase(productId)) {
					details += productList.get(i).getDetails();
					break;
				}
			}
			if(details.isEmpty()) {
				System.out.println("\nNo Item found. Please try again!");
			} else {
				System.out.println(details);
			}
			
			break;
		}
	}
	
	public void customerCheckPromotions() {
		String details = "-------------- ALL DISCOUNTS ----------------\n";
		for(int i = 0; i < discountList.size(); i++) {
			details += discountList.get(i).getDetails();
		}
		System.out.println(details);
	}
	
	public void customerTopUp() {
		while(true) {
			Scanner input = new Scanner(System.in);
			System.out.println("\n- Enter card number: ");
			String cardNo = input.next();
			System.out.println("\n- Enter customer ID: ");
			String customerId = input.next();
			
			CreditCard card = null;
			// check if card exists
			for(int i = 0; i < customerList.size(); i++) {
				if(customerList.get(i).id.equalsIgnoreCase(customerId)) {
					for(int y = 0; y < customerList.get(i).cards.size(); y++) {
						if(customerList.get(i).cards.get(y).cardNumber.equalsIgnoreCase(cardNo)) {
							card = customerList.get(i).cards.get(y);
							break;
						}
					}
				}
			}
			
			if(card == null) { // card does not exist
				System.out.println("\nCard does not exist. Please try again!");
				break;
			} else { // card exist
				double amount = 0;
				while(amount <= 0) {
					System.out.println("\n- Enter Amount: ");
					try {
						amount = input.nextDouble();
						if(amount <= 0) {
							System.out.println("\nAmount must be bigger than 0!");
						} 
					} catch(Exception e) {
						System.out.println("\nAmount must be a number");
						input.next();
					}	
				}
				card.addBalance(amount);
				System.out.println("\nCard has been topped up successfully!");
				System.out.println("\nBalance: " + card.getBalance());
				break;
			}
		
		}
	}
	
	public void generateProducts() {
		Product milk = new Product("p1", "Milk", 3.50);
		Product beef = new Product("p2", "Beef", 19.90);
		Product pasta = new Product("p3", "Pasta", 2.00);
		Product iceCream = new Product("p4", "Ice Cream", 7.50);
		productList.add(milk);
		productList.add(beef);
		productList.add(pasta);
		productList.add(iceCream);
	}
	
	public void generateCustomers() {
		Customer harry = new Customer("c1", "Harry", "Le");
		Customer kim = new Customer("c2", "Kim", "Yan");
		Customer sean = new Customer("c3", "Sean", "Hinds");
		Customer dimple = new Customer("c4", "Dimple", "Saharan");
		
		CreditCard card1 = new CreditCard("111", "c1");
		card1.addBalance(100);
		harry.addCreditCard(card1);
		
		CreditCard card2 = new CreditCard("222", "c2");
		card2.addBalance(100);
		kim.addCreditCard(card2);
		
		CreditCard card3 = new CreditCard("333", "c3");
		card3.addBalance(100);
		sean.addCreditCard(card3);
		
		CreditCard card4 = new CreditCard("444", "c4");
		card4.addBalance(100);
		dimple.addCreditCard(card4);
		
		customerList.add(harry);
		customerList.add(kim);
		customerList.add(sean);
		customerList.add(dimple);
	}
	
	public void generateDiscounts() {
		Discount milkDiscount = new Discount("d1", "p1", 4, 3.00);
		Discount beefDiscount = new Discount("d2", "p2", 1, 17.50);
		Discount iceCreamDiscount = new Discount("d3", "p4", 2, 3.75);
		discountList.add(milkDiscount);
		discountList.add(beefDiscount);
		discountList.add(iceCreamDiscount);
	}
}
