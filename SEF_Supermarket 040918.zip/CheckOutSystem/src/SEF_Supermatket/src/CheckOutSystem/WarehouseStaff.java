package CheckOutSystem;

public class WarehouseStaff {

}
