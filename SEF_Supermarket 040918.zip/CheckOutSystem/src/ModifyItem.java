
public class ModifyItem {
	public ModifyItem() {
		//generateProducts();
		}
	
	public void startModifyItem() {
		System.out.println("***MODIFY ITEM***");
	}

}
