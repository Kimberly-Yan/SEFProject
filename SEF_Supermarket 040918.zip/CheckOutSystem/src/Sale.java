

import java.util.Date;
import java.util.ArrayList;

public class Sale {
	protected String id;
	private Date date;
	ArrayList<SaleLineItem> saleItemList = new ArrayList<SaleLineItem>();
	
	
	public Sale(String id) {
		this.id = id;
		this.date = new Date();
	}
	
	public String getDetails() {
		String details = "\n-----------------------\nPurchase ID: " + id + "\nDate: " + date + "\n-----------------------";
		for(int i = 0; i < saleItemList.size(); i++) {
			details += saleItemList.get(i).getDetails();
		}
		details += "\n-----------------------\nTotal: " + this.getTotal();
		return details;
	}
	
	public void addItemToList(SaleLineItem item) {
		this.saleItemList.add(item);
	}
	
	public void removeItemFromList(SaleLineItem item) {
		this.saleItemList.remove(item);
	}
	
	public double getTotal() {
		double total = 0;
		for(int i = 0; i < saleItemList.size(); i++) {
			total += saleItemList.get(i).getTotal();
		}
		
		return total;
	}
}
