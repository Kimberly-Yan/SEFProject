

public class Product {
	protected String id;
	protected String name;
	protected double price;
	protected double quantity;
	
	public Product(String id, String name, double price) {
		this.id = id;
		this.name = name;
		this.price = price;
		this.quantity = 0;
	}
	
	public void setPrice(double newPrice) {
		this.price = newPrice;
	}
	
	public void addQuantity(double amount) {
		this.quantity += amount;
	}
	
	public void deduceQuantity(double amount) {
		if(amount <= this.quantity) {
			this.quantity -= amount;			
		}
	}
	
	public String getDetails() {
		return "\nProduct ID: " + id + "\nProduct Name: " + name + "\nProduct Price: " + price;
	}
	
	
}
