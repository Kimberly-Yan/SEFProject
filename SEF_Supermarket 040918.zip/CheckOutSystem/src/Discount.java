

public class Discount {
	private String id;
	protected String productId;
	protected int quantityToDiscount;
	protected double discountPrice;
	
	public Discount(String id, String productId, int quantityToDiscount, double discountPrice) {
		this.id = id;
		this.productId = productId;
		this.quantityToDiscount = quantityToDiscount;
		this.discountPrice = discountPrice;
	}
	
	public String getDetails() {
		return "\nProduct ID " + productId + ": Only " + discountPrice + " when you buy " + quantityToDiscount + " or more.";   
	}
}
