

public class MainProgram {

	public static void main(String[] args) {
		CheckOutSystem system = new CheckOutSystem();
		system.startProgram();
	}

}
