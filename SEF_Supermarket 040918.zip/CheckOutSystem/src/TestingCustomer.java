

import static org.junit.Assert.assertEquals;
import org.junit.*;

public class TestingCustomer {
	private Customer customerList[] = new Customer[3];
	
	@Before
	public void generateCustomers() {
		customerList[0] = new Customer("001", "John", "Doe");
		customerList[1] = new Customer("002", "Anna", "Doe");
		customerList[2] = new Customer("003", "Tom", "Jerry");
	}
	
	@Test
	public void testingAddPoints() {
		customerList[0].addPoints(10);
		customerList[2].addPoints(25);
		assertEquals("should add the correct points", customerList[0].getCurrentPoints(), 10, 0);
		assertEquals("should add the correct points", customerList[2].getCurrentPoints(), 25, 0);
	}
	
	@Test
	public void testingDeducePoints() {
		customerList[0].addPoints(25);
		customerList[0].deducePoints(15);
		customerList[1].deducePoints(10);
		
		assertEquals("should deduce the correct points", customerList[0].getCurrentPoints(), 10, 0);
		assertEquals("should not deduce points if amount is bigger than current points", customerList[1].getCurrentPoints(), 0, 0);
		
	}
}
