
public class SupplyReport {
	public SupplyReport() {
		// generateProducts();
	}

	public void startSupplyReport() {
		System.out.println("***SUPPLY REPORT***");
	}

}