

public class SaleLineItem {
	private String productId;
	private String saleId;
	private int quantity;
	private double price;
	
	
	public SaleLineItem(String productId, String saleId, int quantity, double price) {
		this.productId = productId;
		this.saleId = saleId;
		this.quantity = quantity;
		this.price = price;
	}
	
	public double getTotal() {
		return quantity  * price;
	}
	
	public String getDetails() {
		return "\nProductID: " + productId + " - Quantity: " + quantity + " - Price: " + price + " - total: " + this.getTotal();
	}
}
