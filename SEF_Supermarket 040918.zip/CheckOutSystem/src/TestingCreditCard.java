

import static org.junit.Assert.assertEquals;

import org.junit.*;

public class TestingCreditCard {
	private CreditCard cards[] = new CreditCard[3];
	
	@Before
	public void generateProducts() {
		cards[0] = new CreditCard("123123123123", "CUS001");
		cards[1] = new CreditCard("456456456456", "CUS002");
		cards[2] = new CreditCard("789789789789", "CUS003");
	}
	
	@Test
	public void testingAddBalance() {
		cards[0].addBalance(100.00);
		cards[0].addBalance(50.00);
		cards[2].addBalance(75.00);
		
		assertEquals("should add the correct amount", cards[0].getBalance(), 150.00, 0);
		assertEquals("should add the correct amount", cards[2].getBalance(), 75.00, 0);
	}
	
	@Test
	public void deduceBalance() {
		cards[0].addBalance(100.00);
		cards[0].deduceBalance(75.00);
		
		cards[1].addBalance(30.00);
		cards[1].deduceBalance(45.00);
		
		cards[2].addBalance(60.00);
		cards[2].deduceBalance(-20.00);
		
		assertEquals("should deduce the correct amount", cards[0].getBalance(), 25.00, 0);
		assertEquals("should not deduce if amount is bigger than currentBalance", cards[1].getBalance(), 30.00, 0);
		assertEquals("should not deduce if amount is negative", cards[2].getBalance(), 60.00, 0);
	}

}
