
public class HighRevenueItems {
	public HighRevenueItems() {
		// generateProducts();
	}

	public void startHighRevenueItems() {
		System.out.println("***HIGH REVENUE ITEMS***");
	}

}
