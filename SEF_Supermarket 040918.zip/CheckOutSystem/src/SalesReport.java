
public class SalesReport {
	public SalesReport() {
		// generateProducts();
	}

	public void startSalesReport() {
		System.out.println("***SALES REPORT***");
	}

}
