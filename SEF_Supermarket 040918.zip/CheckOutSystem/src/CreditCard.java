

public class CreditCard {
	protected String cardNumber;
	protected String customerId;
	private double balance;
	
	public CreditCard(String cardNumber, String customerId) {
		this.cardNumber = cardNumber;
		this.customerId = customerId;
		balance = 0;
	}
	
	public String getCardNumber() {
		return this.cardNumber;
	}
	
	public double getBalance() {
		return this.balance;
	}
	
	public void addBalance(double amount) {
		this.balance += amount;
	}
	
	public void deduceBalance(double amount) {
		if(this.balance < amount) {
			// throw error
			
		} else {
			if(amount > 0) {
				this.balance -= amount;							
			}
		}
	}
	
	public boolean makePayment(double amount) {
		if(balance < amount || amount < 0) {
			return false;
		} else {
			balance -= amount;
			return true;
		}
	}
}
