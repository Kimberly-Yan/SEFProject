

public class Supplier {
	private String id;
	private String name;
	private String address;
	protected String comment;
	
	public Supplier(String id, String name, String address) {
		this.id = id;
		this.name = name;
		this.address = address;
	}
	
	public String getComment(String comment) {
		if(this.comment == null) {
			return "No comments yet.";
		}
		return this.comment;
	}
	
}
