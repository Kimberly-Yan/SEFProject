
import java.util.Scanner;

public class Manager {
	public Manager() {
		// generateProducts();
	}

	public void startManager() {

		Scanner input = new Scanner(System.in);

		// Manager Login
		System.out.println("Enter Manager Username");
		String managerUsername = input.nextLine();
		System.out.println("Enter Manager Password");
		String managerPassword = input.nextLine();

		if (managerUsername.equals("manager") && managerPassword.equals("password")) {
			int choice;
			do {
				System.out.println("1. Modify Item");
				System.out.println("2. Place Purchase Report");
				System.out.println("3. Generate Supply Report");
				System.out.println("4. Generate Sales Report");
				System.out.println("5. High Revenue Items");
				System.out.println("6. Back to Staff Menu");

				choice = input.nextInt();

				if (choice == 1) {
					ModifyItem modifyitem = new ModifyItem();
					modifyitem.startModifyItem();
				}

				if (choice == 2) {
					PlacePurchaseOrder placepurchaseorder = new PlacePurchaseOrder();
					placepurchaseorder.startPurchaseOrder();
				}

				if (choice == 3) {
					SupplyReport supplyreport = new SupplyReport();
					supplyreport.startSupplyReport();
				}

				if (choice == 4) {
					SalesReport salesreport = new SalesReport();
					salesreport.startSalesReport();
				}

				if (choice == 5) {
					HighRevenueItems highrevenue = new HighRevenueItems();
					highrevenue.startHighRevenueItems();
				}

				else if (choice > 6 || choice < 1) {
					System.out.println("This is not a valid choice, please enter valid choice");
				}
			} while (choice != 6);
		} else {
			System.out.println("Invalid username or password");
		}

	}

}
