

import static org.junit.Assert.assertEquals;

import org.junit.*;

public class TestingProduct {
	private Product products[] = new Product[3];
	
	@Before
	public void generateProducts() {
		products[0] = new Product("001", "Milk", 3.50);
		products[1] = new Product("002", "Beef", 15.00);
		products[2] = new Product("003", "Ice Cream", 8.75);
	}
	
	@Test
	public void testingAddQuantity() {
		products[0].addQuantity(1000);
		products[2].addQuantity(750);
		assertEquals("Should add the correct quantity to products", 1000, products[0].quantity, 0);
		assertEquals("Should add the correct quantity to products", 750, products[2].quantity, 0);
		
		products[2].addQuantity(750);
		assertEquals("should accumulate quantity of products", products[2].quantity, 1500, 0);
	}
	
	@Test
	public void testingDeduceQuantity() {
		products[0].addQuantity(1000);
		products[0].deduceQuantity(250);
		assertEquals("Should deduce the correct amount", 750, products[0].quantity, 0);
		
		products[2].addQuantity(750);
		products[2].deduceQuantity(800);
		assertEquals("should remains the same quantity if amount is bigger than quantity", 750, products[2].quantity, 0);
	}
	
	@Test
	public void testingSetPrice() {
		products[0].setPrice(4.00);
		products[1].setPrice(17.50);
		assertEquals("should set the correct price", 4.00, products[0].price, 0);
		assertEquals("should set the correct price", 17.50, products[1].price, 0);
	}

}
