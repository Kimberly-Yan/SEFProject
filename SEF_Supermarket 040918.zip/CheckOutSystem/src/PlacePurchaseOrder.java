
public class PlacePurchaseOrder {
	public PlacePurchaseOrder() {
		// generateProducts();
	}

	public void startPurchaseOrder() {
		System.out.println("***PURCHASE ORDER***");
	}

}
